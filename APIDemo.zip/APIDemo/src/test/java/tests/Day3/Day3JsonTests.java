package tests.Day3;


import static io.restassured.RestAssured.given;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class Day3JsonTests {

    @Test
    public void verifyFriendAddedSimple_Test() {
        JSONObject friendInfo = new JSONObject();
        friendInfo.put("firstname","vaibhav");
        friendInfo.put("lastname","barmkar");
        friendInfo.put("id",50);
        friendInfo.put("age",30);
    	given().
    		contentType(ContentType.JSON).
    		body(friendInfo.toString()).
    	when().
    		post("http://localhost:3000/friends").
    	then().
    		assertThat().
    		statusCode(201);
    }
    
    @Test
    public void verifyFriendAddedComplexJson_Test() {
        JSONObject addressInfo = new JSONObject();
        addressInfo.put("houseNo","111");
        addressInfo.put("streetName","snbp road");       
        JSONObject friendInfo = new JSONObject();
        friendInfo.put("firstname","mahesh1");
        friendInfo.put("lastname","bhandigare1");
        friendInfo.put("id",1000);
        friendInfo.put("age",30);
        friendInfo.put("address",addressInfo);    
    	given().
    		contentType(ContentType.JSON).
    		body(friendInfo.toString()).
    	when().
    		post("http://localhost:3000/friends").
    	then().
    		assertThat().
    		statusCode(201).log().all();
    }

    @Test
    public void verifyFriendAddedComplexJsonArray_Test() {
    	JSONArray address = new JSONArray();
        JSONObject primaryAddress = new JSONObject();
        primaryAddress.put("houseNo","111");
        primaryAddress.put("streetName","snbp road");  
        JSONObject secondaryAddress = new JSONObject();
        secondaryAddress.put("houseNo","121");
        secondaryAddress.put("streetName","back snbp road");
        address.put(0,primaryAddress);
        address.put(1,secondaryAddress);
        JSONObject friendInfo = new JSONObject();
        friendInfo.put("firstname","mahesh");
        friendInfo.put("lastname","bhandigare");
        friendInfo.put("id",100);
        friendInfo.put("age",30);
        friendInfo.put("address",address);    
    	given().
    		contentType(ContentType.JSON).
    		body(friendInfo.toString()).
    	when().post("http://localhost:3000/friends").
    	then().assertThat().statusCode(201);
    }
   
}
