package tests.Day3;


import static io.restassured.RestAssured.given;
import java.io.File; 

import org.testng.annotations.Test;

import io.restassured.http.ContentType;

public class Day3JsonFileTests {

    @Test
    public void verifyFriendAddedJSONFile_Test() {
    	File file = new File("src/test/resources/friend.json");

    	given().
    		contentType(ContentType.JSON).
    		body(file).
    	when().
    		post("http://localhost:3000/friends").
    	then().
    		assertThat().
    		statusCode(201);
    }
   
}
