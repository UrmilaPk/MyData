package tests.Day3;
import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import java.util.Map;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utilities.ExcelUtility;

public class Day3Tests {
	
	 @Test
    public void requestUsZipCode90210_checkPlaceNameInResponseBody_expectBeverlyHills() {
        given().
        when().
            get("http://zippopotam.us/us/90210").
        then().
            assertThat().
            body("places[0].'place name'", equalTo("Beverly Hills"));
    }
	 
	 @Test
	    public void requestUsZipCode90210_checkPlaceNameInResponseBody_expectBeverlyHills1() {
	        given().pathParam("countryCode", "us").pathParam("zipCode", "90210").
	        when().
	            get("http://zippopotam.us/{countryCode}/{zipCode}").
	        then().
	            assertThat().
	            body("places[0].'place name'", equalTo("Beverly Hills"));
	    }

    @Test
    public void requestUsZipCode12345_checkPlaceNameInResponseBody_expectSchenectady() {

        given().
        when().
            get("http://zippopotam.us/us/12345").
        then().
            assertThat().
            body("places[0].'place name'", equalTo("Schenectady"));
    }

    @Test
    public void requestCaZipCodeB2R_checkPlaceNameInResponseBody_expectWaverley() {

        given().
        when().
            get("http://zippopotam.us/ca/B2R").
        then().
            assertThat().
            body("places[0].'place name'", equalTo("Waverley"));
    }
	    
	@DataProvider
    public static Object[][] zipCodesAndPlaces() {
        return new Object[][] {
            { "us", "90210", "Beverly Hills" },
            { "us", "12345", "Schenectady" },
            { "ca", "B2R", "Waverley"}
        };
    }

    @Test(dataProvider = "zipCodesAndPlaces")
    public void requestZipCodes_checkPlaceNameInResponseBody_expectSpecifiedPlaceName(String countryCode, String zipCode, String expectedPlaceName) {

        given().
            pathParam("countryCode", countryCode).pathParam("zipCode", zipCode).
        when().
            get("http://zippopotam.us/{countryCode}/{zipCode}").
        then().
            assertThat().
            body("places[0].'place name'", equalTo(expectedPlaceName));
    }
    

    @Test(dataProvider = "getApiEndPointData", dataProviderClass = ExcelUtility.class,testName="verifyExcelDataProvider_BookTest")
    public void verifyExcelDataProvider_BookTest(String methodName, String serviceEndpoint, Map<String,String> headerMap, Map<String,String> queryParamMap,Map<String,Object> pathParamMap,int statusCode,String responseMessage) {
System.out.println(pathParamMap);
    	given().
    		pathParams(pathParamMap).
        when().
            get(serviceEndpoint).
        then().
            assertThat().
            statusCode(statusCode).
            body("places[0].'place name'", equalTo(responseMessage));
    }

   
}
