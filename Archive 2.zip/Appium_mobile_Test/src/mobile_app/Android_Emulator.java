package mobile_app;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.w3c.dom.Text;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;

public class Android_Emulator {
	
	public static void main(String[] args) throws MalformedURLException, InterruptedException {
		
		DesiredCapabilities dc=new DesiredCapabilities();
		dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Uiautomator2");
		dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Pixel_4_API_30");
		dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "11.0");
		dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		dc.setCapability(MobileCapabilityType.APP, "/Users/urmila.dulange/Documents/com.llamalab.automate_199_apps.evozi.com.apk");
		
		URL url=new URL("http://0.0.0.0:4723/wd/hub");
		AndroidDriver driver= new AndroidDriver(url,dc);
		driver.findElement(By.id("android:id/button1")).click();
		driver.findElement(By.xpath("//android.widget.ImageButton[@content-desc=\"Open drawer\"]")).click();
		driver.findElement(By.xpath("//*[@text='Settings']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@text='Theme']")).click();
		driver.findElement(By.xpath("//*[@text='Dark']")).click();
	   // driver.quit();
	   //600 812
		//600 2009
//		boolean b=false;
//		while(!b){
//		try {
//		  driver.findElement(By.xpath("//*[@text='Privacy policy']")).click();
//		  b=true;
//		}
//		catch(NoSuchElementException e){
//		TouchAction ac=new TouchAction(driver).press(PointOption.point(581,2000))
//	    .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
//		.moveTo(PointOption.point(581,400)).release().perform();
//		}}
	
	  driver.findElement(By.xpath("//android.widget.TextView[@text='Notification channels']")).click();
	  driver.findElement(By.id("com.llamalab.automate:id/create")).click();
	  driver.findElement(By.id("com.llamalab.automate:id/name")).sendKeys("UPK");
}}
