package TokenPractice;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;

import static io.restassured.RestAssured.given;

public class ReqRes {
	@BeforeTest
	public void browse(){
		
		
	}
	
	
	@Test
	public void req() {
	given().
	contentType(ContentType.JSON).
	body("\"userEmail\", \"urmilDpk@gmail.com\",\"userPassword\", \"Upk123456789@28\"").
	when().
	 post("https://rahulshettyacademy.com/api/ecom/auth/login");
	}

}
