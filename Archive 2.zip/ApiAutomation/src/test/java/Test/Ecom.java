package Test;
import static io.restassured.RestAssured.*;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Ecom {
	
	String token;
	String productId;
	private static RequestSpecification requestSpec;
	
	@BeforeMethod
	public void addheader()
	{
		requestSpec=new RequestSpecBuilder().
				setBaseUri("https://rahulshettyacademy.com/").
				build();
				
	}
	
	@Test(priority=1)
	public void login()
	{
		JSONObject credentials=new JSONObject();
		credentials.put("userEmail", "kamleshpatle90@gmail.com");
		credentials.put("userPassword", "Kpatle@90");
		
		Response response=
				given().spec(requestSpec).
					contentType(ContentType.JSON).
					body(credentials.toString()).
				when().
					post("api/ecom/auth/login");
		
		JsonPath jsonPath=response.jsonPath();
		 token=jsonPath.get("token");		
		
	}
	
	@Test(priority=2,enabled=true)
	public void createProduct()
	{		
		File file = new File("/Users/kamlesh.patle/eclipse-workspace/Kamlesh_Patle/resource/productImage.jpeg");
		
//		Map<String,String> formBody=new HashMap<String,String>();
//		formBody.put("productName","Orange");
//		formBody.put("productAddedBy","62ecf064e26b7e1a10f51329");
//		formBody.put("productCategory","Food");
//		formBody.put("productSubCategory","citrus fruit");
//		formBody.put("productPrice","20");
//		formBody.put("productDescription","Farmers Originals");
//		formBody.put("productFor","Common");
		
		JsonPath response=given().
			spec(requestSpec).
			param("productName","Orange").
			param("productAddedBy","62ecf064e26b7e1a10f51329").
			param("productCategory","Food").
			param("productSubCategory","citrus fruit").
			param("productPrice","20").
			param("productDescription","Farmers Originals").
			param("productFor","Common").
			multiPart("productImage", file).
			header("Authorization", token).
		when().
			post("api/ecom/product/add-product"). 
		then(). 
			extract().jsonPath();	
		 productId = response.getString("productId");		
	}
	
	@Test(priority=3)
	public void createorder()
	{
		JSONObject orderbody=new JSONObject();
		JSONArray order= new JSONArray();
		JSONObject orderdetails=new JSONObject();
		orderdetails.put("country", "India");
		orderdetails.put("productOrderedId", productId);
		order.put(0,orderdetails);
		orderbody.put("orders", order);
	
		given().log().all().
			contentType(ContentType.JSON).
			header("Authorization", token).
			spec(requestSpec).
			body(orderbody.toString()).
		when().
			post("api/ecom/order/create-order").
		then().log().all();
		
	}
	
	@Test(priority=4,enabled=true)
	public void deleteOrder()
	{
		given().
			contentType(ContentType.JSON).pathParam("productId", productId).
			header("Authorization", token).
		when().
			delete("https://rahulshettyacademy.com/api/ecom/product/delete-product/{productId}"). 
		then().
			assertThat().body("message", Matchers.equalTo("Product Deleted Successfully"));
	}
	

}


