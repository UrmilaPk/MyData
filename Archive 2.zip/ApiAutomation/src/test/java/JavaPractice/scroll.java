package JavaPractice;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class scroll {
	public static void main(String[] args) throws InterruptedException {
		
	WebDriver driver=WebDriverManager.chromedriver().create();
	driver.get("https://www.amazon.in");
    driver.manage().window().maximize();
	WebElement element=driver.findElement(By.xpath("//a[@href='https://www.amazon.in/ap/signin?openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fref%3Drhf_sign_in&openid.assoc_handle=inflex&openid.pape.max_auth_age=0']"));	
	
	//WebElement element=driver.findElement(By.xpath("//h2[@class='as-title-block-left']/span[text()='Health & beauty bestsellers']"));
	JavascriptExecutor js = (JavascriptExecutor) driver; 
	js.executeScript("arguments[0].scrollIntoView();",element);
	Thread.sleep(5000);
//	driver.findElement(By.xpath("//img[@alt='TERRAVITA Hair Vitamins (for Men & Women)Plant based Biotin, Bamboo Shoot, All Natural Vitamins A, C, D, E|For stronger...']")).click();
	driver.findElement(By.xpath("//a[@href='https://www.amazon.in/ap/signin?openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fref%3Drhf_sign_in&openid.assoc_handle=inflex&openid.pape.max_auth_age=0']")).click();	
	
	
	
	}

}
