package shadowrootxpath;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class shadowroot {
	public static void main(String[] args) throws InterruptedException {
		
	WebDriver driver=WebDriverManager.chromedriver().create();
	
	driver.get("https://books-pwakit.appspot.com/");
	JavascriptExecutor js=(JavascriptExecutor)driver;
	WebElement enterBN=(WebElement)js.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"app-header > app-toolbar >book-input-decorator #input\")");
	enterBN.sendKeys("Harry Potter");
	enterBN.sendKeys(Keys.ENTER);
	Thread.sleep(10000);
	
	JavascriptExecutor js1=(JavascriptExecutor)driver;
	WebElement bookUl=(WebElement)js1.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"main > book-explore._page\").shadowRoot.querySelector(\"section > ul\")");
	List<WebElement> booklist = bookUl.findElements(By.cssSelector("li"));
	System.out.println(booklist.size());
	
	
	for(int i=1;i<booklist.size();i++)
	{JavascriptExecutor jse1=(JavascriptExecutor)driver;
	// WebElement bookTitle=	(WebElement)jse1.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"main > book-explore\").shadowRoot.querySelector(\"section > ul > li:nth-child("+i+") > book-item\").shadowRoot.querySelector(\"h2\")");
	//WebElement bookTitle=(WebElement)jse1.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"main > book-explore\").shadowRoot.querySelector(\"section > ul > li:nth-child("+i+") > book-item\").shadowRoot.querySelector(\"h2\")");
	//System.out.println(bookTitle.getText());
		String bookName=((bookUl.findElement(By.cssSelector("li:nth-child("+i+") > book-item"))).getShadowRoot()).findElement(By.cssSelector("h2.title")).getText();
		if(bookName.equalsIgnoreCase("The Harry Potter Generation")) {
			WebElement bookTitle=(WebElement)jse1.executeScript("return document.querySelector(\"book-app\").shadowRoot.querySelector(\"main > book-explore\").shadowRoot.querySelector(\"section > ul > li:nth-child("+i+") > book-item\").shadowRoot.querySelector(\"h2\")");
			jse1.executeScript("arguments[0].scrollIntoView();",bookTitle);
			Thread.sleep(5000);
			bookTitle.click();
			Thread.sleep(5000);
		}
			
			
			
	 //System.out.println(bookTitle);
	}
	driver.quit();
}
}