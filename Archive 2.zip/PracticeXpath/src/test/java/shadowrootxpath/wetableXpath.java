package shadowrootxpath;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class wetableXpath {
	public static void main(String[] args) {
	WebDriver driver=WebDriverManager.chromedriver().create();
		driver.get("https://cosmocode.io/automation-practice-webtable");
		List<WebElement> li=driver.findElements(By.xpath("//table[@id='countries']/tbody/tr/td[2]"));
		List<WebElement> li1=driver.findElements(By.xpath("//table[@id='countries']/tbody/tr/td[4]"));
	  for(int i=0;i<li.size();i++) {
		  System.out.println(li.get(i).getText()+":"+li1.get(i).getText());
	  }
	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(0));
	 
	}
	

}
