package Test;

import java.util.Map;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Utility.APIConstant;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import modules.GetPostsResource;


public class Day4assign2_Framework_Tests {
	
	GetPostsResource getPostsResource = new GetPostsResource();
	SoftAssert softAssert = new SoftAssert();
	
	@Test(dataProvider = "getApiEndPointData", dataProviderClass = Utility.ExcelUtility.class,testName="verifyExcelDataProvider_BookTest")
    public void verifyExcelDataProvider_BookTest(String methodName, String serviceEndpoint, Map<String,String> headerMap, Map<String,String> queryParamMap,Map<String,Object> pathParamMap,int statusCode,String responseMessage, String assertMessage) {
		ResponseOptions<Response> response = getPostsResource.getPlaceNameDetails(methodName,serviceEndpoint,headerMap,queryParamMap,pathParamMap,assertMessage);
		if(methodName.equalsIgnoreCase(APIConstant.ApiMethods.POST)) {
			softAssert.assertEquals(response.getStatusCode(), 201,"Status code failed");
		}
		else {
			softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
			softAssert.assertEquals(response.body().jsonPath().getString(assertMessage), responseMessage,"Place name not matched");
		}
		softAssert.assertAll();
		
    }
	
	

}
