package Test;

import org.testng.annotations.Test;

import io.restassured.module.jsv.JsonSchemaValidator;
import static io.restassured.RestAssured.*;

public class Day6assign1 
{
	
	@Test
	public void validateSchema()
	{		
		given().
			log().all().
		when().
			get("http://localhost:3000/friends").
		then().
			assertThat().body(JsonSchemaValidator.matchesJsonSchemaInClasspath("FriendsSchema.json"));	
	}

}
