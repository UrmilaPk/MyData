package Test;


import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.hasItem;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


//Code Optimization with RequestSpecification and ResponseSpecification

public class Day4assign1 
{
	private static RequestSpecification requestSpec;
	private static ResponseSpecification responseSpec;
	
	@BeforeClass
	public static void createResquestResponseSpec()
	{
		requestSpec=new RequestSpecBuilder().
				setBaseUri("http://localhost:3000").
				build();
		
		responseSpec=new ResponseSpecBuilder().
				expectStatusCode(200).
				expectContentType(ContentType.JSON).
				build();		
	}
	

	
	@Test
	public void verifyFriendsAddedSimple_Test()
	{		
		given().
			spec(requestSpec).
		when().
			get("friends"). 
		then().
			spec(responseSpec).
			assertThat().
			body("firstname", hasItem("Sachin"));
	}
	
	//Extracting response values with reuse example
	@Test
	public void verifyExtractResponse()
	{
		String response=given().
			spec(requestSpec).
		when().
			get("/friends").
		then().
			extract().
			path("[0].firstname");
		Assert.assertEquals("Sachin", response);
	}

	@Test
	public void verifyFriendsAddedMedium_Test()
	{
		given().
			spec(requestSpec).
		when().
			get("/posts").
		then().
			spec(responseSpec).
			assertThat().
			body("author", hasItem("Sachin F"));
		
	}


	@Test
	public void verifyFriendsAddedComplex_Test()
	{		
		given().
			spec(requestSpec).
		when().
			get("/comments").
		then().
			spec(responseSpec).
			assertThat().
			body("body", hasItem("some comment globant 1"));
	}
	
	


}
