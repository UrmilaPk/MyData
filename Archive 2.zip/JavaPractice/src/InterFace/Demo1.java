package InterFace;

public interface Demo1 {
	public int test1();
	public void test2();
	
}
