package InterFace;

public class Implement implements Demo1,Demo2 {

	@Override
	public int test1() {
		System.out.println("this is test1");
	}
     
	@Override
	public void test2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void test3() {
		// TODO Auto-generated method stub
		
	}
	}

 class Run{
	 
	 public static void main(String[] args) {
		 Demo1 d1=new Implement();
		 Demo1 d2=new Implement();
		 d1.test1();
		 d2.test1();
	}
	
}
