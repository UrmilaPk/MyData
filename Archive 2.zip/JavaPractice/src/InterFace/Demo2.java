package InterFace;

public interface Demo2 {
	
	public void test1();
	public void test3();
}
