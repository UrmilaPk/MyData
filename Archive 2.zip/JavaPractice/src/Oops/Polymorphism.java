package Oops;

public class Polymorphism {
	
	public Polymorphism(int e,int j) {
		
		
	}
	
	public int sum(int c,int d) {
		int e=c+d;
		return e;
	}
	
	public static void main(String[] args) {
		Polymorphism pl=new Polymorphism(3,4);
		
	}

}
