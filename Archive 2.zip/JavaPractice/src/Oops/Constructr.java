package Oops;

public class Constructr {
	  
	public Constructr(int a,int b) {
		int d=sum(4,5)+a+b;
		System.out.println(d);
		
	}
	
	public int sum(int a,int b) {
		return a+b;
	}
	
	public static void main(String[] args) {
		
		Constructr s=new Constructr(3,4);
		s.sum(4, 5);
//		System.out.println(s.sum(4, 5));
//		System.out.println(s.sum(4, 5));
		Constructr s1=new Constructr(2,4);
		Constructr s11=new Constructr(5,4);
		Constructr s111=new Constructr(36,4);
	}

}
//1.we can constructor only from another constructor not from method 
//2. if we want to call current class constructor then then we can do it using this()
//3. if we want to call parent class/superclass constructor then we can do it using super()
//constructor overloading is possible
//inheritence / overriding concept is not available for constructor
//abstract class can have constructor,bcz abstract class can contain instance variaable
//constructor are not available for interface
//every variable inside interface is by default public static final , so we can not create object of static methods/variables so not require constructor
//there is no chance of existing even single instance variable