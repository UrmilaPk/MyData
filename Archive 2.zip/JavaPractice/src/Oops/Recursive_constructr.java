package Oops;

public class Recursive_constructr {
	public Recursive_constructr() {
		this(10);
		
	}
    public Recursive_constructr(int i) {
    	this();
    }
//	public static void m1() {
//		m2();
//	}
//	
//	public static void m2() {
//		m1();
//	
//	}
//	public static void main(String[] args) {
//		m1();
//		System.out.println("hello");
//	}
	
}
// recursive constructr is not possible it gives compile time error recursive constructor invocation