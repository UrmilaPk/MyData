package Oops;

public class Super_This_keywords {
	
	String s="Parent class variable";    //instance variables
	int i=10;

}

class child extends Super_This_keywords{
	
	String s="child class variable";    //instance variables of child class
	int i=10;
	
	public void call() {
		                                      // O/P:
		System.out.println(s);                // child class variable
		System.out.println(this.s);           // child class variable
		System.out.println(super.s);          //parent class variable
		
	}
	
	
}
//super,this ---keywords
//1.to refer superclass/parent class instance variables we use super keyword
//2.to refer current class instance variables we use this keyword
//3.when parent and child class same name variable or method then we require to differentiate using super and this to call them 
//4.anywhere we can use super and this except static area(method,variable)