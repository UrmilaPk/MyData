package Oops;

interface InterfFace {

	public void m1();
	public void m2();

}

//1. Every method inside interface is by default public and abstract.
//2.while implementing any method inside interface compulsory we need to provide access modifier as public only 
//i.e we provide body to methods inside interface in implementation class i.e in child class we override that methods and while overriding methods
//we can't reduce scope of access modifier of parent class methods 
//3. whenever we are implementing an interface for each and every method in interface we need to provide implementation/body'
// if we are unable to provide implementation to atleast one abstract method then declare that class as abstract class

//class Interf implements InterfFace {
//
//	@Override
//	public void m1() {}
//
//	@Override
//	public void m2() {}
//		
//}

abstract class Interf implements InterfFace{
	
	public void m1() {
		int a=10;
	}
}

// after making class as abstract only child class can provide implementation to unimplemented methods 


class SubInterf extends Interf{

	@Override
	public void m2() {
		
	}
	SubInterf sb=new SubInterf();

}