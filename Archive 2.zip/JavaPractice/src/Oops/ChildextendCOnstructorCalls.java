package Oops;

public class ChildextendCOnstructorCalls extends ConstructorCalls {
	

//case 1: not written any constructor, here default constructor get calls.
//	default constructor: 
//                	ChildextendCOnstructorCalls(){
//	                             super();     is calls parent class no arg constructor  
//                          } 
// default constructor is always is a no arg constructor, and always include super() in that.
	
//Case 2: 	
//	public ChildextendCOnstructorCalls(){
//		
//	}
	
//Solution 1:
//	public ChildextendCOnstructorCalls(int a) {
//	  super(10);
//  }
	
//Solution 2: default constructor gets called	

}
