package Oops;

final class FinalClass {
	
//	public abstract void m1();// if class contains abstract atleast on method also as abstract method then class modifier of that should be abstract 
 
   int i;
   String s;
   
   public static void main(String[] args) {
	FinalClass fc=new FinalClass();
	fc.i=10;
	fc.s="Hello";
	
}
	
}
//If class is final child class creation not possible
//we can create object of final class