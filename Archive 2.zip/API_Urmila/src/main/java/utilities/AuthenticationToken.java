package utilities;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class AuthenticationToken {

//	public String getAuthenticationToken() {
//		File file = new File("./src/test/resources/auth.json");
//		RequestSpecBuilder builder = new RequestSpecBuilder(); 
//		String validRequest = "{\n" +
//	            "  \"userName\": \"smita.shewale\",\n" +
//	            "  \"password\": \"Smita@123\" \n}";
////		Map<String, String> payload = new HashMap<String, String>();
////		payload.put("username", "mahesh");
////		payload.put("password", "mahesh");
//		//builder.setBody(validRequest);
//		
//		//builder.setBody(file);
//		RequestSpecification requestSpecification = builder.build();
//        RequestSpecification request = RestAssured.given();
//        request.contentType(ContentType.JSON);
//        request.spec(requestSpecification);
//        request.body(file);
//        String token = request.post("https://bookstore.toolsqa.com/Account/v1/Authorized").getBody().asString();
//        System.out.println("token"+token);
//        return token;
//	}
	
	public String getAuthenticationToken() throws IOException
	{
		Properties prop=new Properties();
		FileReader reader=new FileReader("./src/test/java/TestData.properties");
		prop.load(reader);
		RequestSpecification request=RestAssured.given();
		request.contentType(ContentType.JSON);
		System.out.println(prop.get("token_link").toString());
		Response response=request.get("http://Fmc-env.eba-5akrwvvr.us-east-1.elasticbeanstalk.com/fmc/token");
		JsonPath js=response.jsonPath();
		String token=js.get("accessToken");
		return token;			
	}
}
