package tests;

import java.io.IOException;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import modules.UserSignUp;
import utilities.AuthenticationToken;
import utilities.ExcelUtility;
import utilities.RestAssuredEngine;

public class BaseTest {

	public ResponseOptions<Response> response;
	RestAssuredEngine restAssuredEngine;
	protected String secureToken = "";
	
    @BeforeSuite
    public void beforeSuite() throws IOException{
    	AuthenticationToken token = new AuthenticationToken();
    	secureToken = token.getAuthenticationToken();
    	restAssuredEngine = new RestAssuredEngine(secureToken);
    	System.out.println(secureToken);
    }
    
    UserSignUp userSignUp = new UserSignUp();
	SoftAssert softAssert = new SoftAssert();
	RequestSpecification requestSpecification;
	String otp="";
	
	
//	@Test(dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
//	public void VerifyEmailFieldWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
//	{
//		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
//		softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
//		JsonPath js=response.getBody().jsonPath();
//		otp=js.get("content.otp");
//		System.out.println(otp);
//	}
//    

}
