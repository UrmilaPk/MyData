package modules;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.FriendWithLombok;
import utilities.RestAssuredEngine;

import java.io.File;
import java.nio.file.Paths;
import java.util.Map;

public class FriendsHelper {
	
	public ResponseOptions<Response> addFriends(String methodName, String serviceEndpoint, Object body){
		RestAssuredEngine restAssuredEngine = new RestAssuredEngine("token");
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, body);
	}

	public FriendWithLombok getFriendsPayload(String payload) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			FriendWithLombok friend = mapper.readValue(payload, FriendWithLombok.class);
			Faker faker=new Faker();
			friend.setId(faker.random().nextInt(500));
			return friend;
		} catch (Exception e) {
		}
		return null;
	}
}
