package tests.FrameworkTests;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import modules.CountryHelper;
import modules.UserSignUp;
import tests.BaseTest;
import utilities.ExcelUtility;

public class FrameworkExcelTests  extends BaseTest {
	CountryHelper countryhelper = new CountryHelper();
	UserSignUp userSignUp = new UserSignUp();
	SoftAssert softAssert = new SoftAssert();
	RequestSpecification requestSpecification;
	String otp="";
	
//	@Test(enabled=false, dataProvider = "getApiEndPointData", dataProviderClass = ExcelUtility.class,testName="verifyPlaceNameFramework_CountryTest")
//    public void verifyPlaceNameFramework_CountryTest(String methodName, String serviceEndpoint, Map<String,String> headerMap, Map<String,String> queryParamMap,Map<String,Object> pathParamMap,int statusCode,String responseMessage) {
//		ResponseOptions<Response> response = countryhelper.getPlaceNameDetails(methodName,serviceEndpoint,headerMap,queryParamMap,pathParamMap);
//		softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
//		softAssert.assertEquals(response.body().jsonPath().getList("places.'place name'").get(0), responseMessage,"Place name not matched");
//		softAssert.assertAll();
//    }
	
	
	@Test(enabled=false)
	public void getAuthenticationToken() throws IOException
	{
		Properties prop=new Properties();
		FileReader reader=new FileReader("./src/test/java/TestData.properties");
		prop.load(reader);
		RequestSpecification request=RestAssured.given();
		request.contentType(ContentType.JSON);
		Response response=request.get(prop.getProperty("token_link").toString());
		JsonPath js=response.jsonPath();
		String token=js.get("accessToken");
		System.out.println(token);	
	}
//	methodName.getStringCellValue(),SERVICE_ENDPOINT, payload, (int)statusCodeCell.getNumericCellValue()};
//	@Test(dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
//	public void VerifyEmailFieldWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
//	{
//		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
//		softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
//		JsonPath js=response.getBody().jsonPath();
//		otp=js.get("content.otp");
//		System.out.println(otp);
//	}
	
	
	@Test(dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
	public void VerifyEmailFieldWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
		JsonPath js=response.getBody().jsonPath();
		otp=js.get("content.otp");
		System.out.println(otp);
	}
	
}