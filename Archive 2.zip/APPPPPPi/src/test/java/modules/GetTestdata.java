package modules;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class GetTestdata {
	
	public Object getValue(String key) throws IOException
	{
		Properties prop=new Properties();
		FileReader reader=new FileReader("/Users/kamlesh.patle/eclipse-workspace/Kamlesh_Patle/src/test/resources/TestData.properties");
		prop.load(reader);
		return prop.get(key);	
	}

}
