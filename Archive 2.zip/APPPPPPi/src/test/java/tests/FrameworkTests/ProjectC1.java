package tests.FrameworkTests;

import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import tests.BaseTest;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import modules.GetTestdata;
import modules.UserSignUp;
import modules.VerifyReportFunctionality;
import pojo_models.Report;
import pojo_models.UserInfoWithLombok;
import Utility.ExcelUtility;

public class ProjectC1 extends BaseTest{
	
	UserSignUp userSignUp = new UserSignUp();
	UserInfoWithLombok userInfo;
	VerifyReportFunctionality verifyReportFunctionality=new VerifyReportFunctionality();
	Report report=new Report();
	SoftAssert softAssert = new SoftAssert();
	RequestSpecification requestSpecification;
	GetTestdata getTestdata=new GetTestdata();
	String otp="";
	int userId;
	int content;
	Map<String , String> pathParamMap=new LinkedHashMap<String , String> ();
	
	
	// Email signup functionality
	@Test(enabled=true,priority=0,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
	public void VerifyEmailFieldValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);		
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
		JsonPath js=response.getBody().jsonPath();
		otp=js.getString("content.otp");
		System.out.println(otp);
		
	}
	
	@Test(priority=1,enabled=false,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidEmailId_FMCTest")
	public void VerifyEmailFieldInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=2,enabled=false,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidToken_FMCTest")
	public void VerifyEmailFieldInvalidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		String inValidToken="eyJhbGciOiJIUzUxMiJ9.eyJyb2xlIjpbIlVTRVIiXSwic3ViIjoiZm1jIiwiaWF0IjoxNjY5MDk0ODI4LCJleHAiOjE2NjkxMDA4Mjh9.cWwnhBxnRfN3NrSyCxRwpi7sJ0W9VsrSRSR4gnf2303WxyHYHrHWpTJX45mcJPr6TBX4Is_1Ihr_vJU6Wi0glw";
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, inValidToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	// verify otp functionality
	@Test(priority=3,enabled=true,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpValidOtp_FMCTest")
	public void VerifyOtpValidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		userInfo=userSignUp.getUserInfoPayload(payload);
		userInfo.setOtp(otp);
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);		
//		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
//		softAssert.assertAll();
	}
	
	@Test(priority=4,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidOtp_FMCTest")
	public void VerifyOtpInvalidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();

	}
	
	@Test(priority=5,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidEmailId_FMCTest")
	public void VerifyOtpInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		userInfo=userSignUp.getUserInfoPayload(payload);
		userInfo.setOtp(otp);	
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=5,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPhoneNo_FMCTest")
	public void VerifyOtpInvalidPhoneNo_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		userInfo=userSignUp.getUserInfoPayload(payload);
		userInfo.setOtp(otp);
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		System.out.println(response.getStatusCode());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=5,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPassword_FMCTest")
	public void VerifyOtpInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		userInfo=userSignUp.getUserInfoPayload(payload);
		userInfo.setOtp(otp);
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		System.out.println(response.getStatusCode());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=5,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidName_FMCTest")
	public void VerifyOtpInvalidName_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		userInfo=userSignUp.getUserInfoPayload(payload);
		userInfo.setOtp(otp);
		ResponseOptions<Response> response = userSignUp.verifyValidOtp(methodName,serviceEndpoint,userInfo, secureToken);
		System.out.println(response.getStatusCode());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	// login functionality
	@Test(priority=6,enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailValidPassword_FMCTest")
	public void VerifyLoginValidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		JsonPath js=response.getBody().jsonPath();
		userId=js.getInt("content.userId");
//		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
//		softAssert.assertAll();
	}
	
	@Test(priority=6,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailInvalidPassword_FMCTest")
	public void VerifyLoginValidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=6,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInvalidEmailValidPassword_FMCTest")
	public void VerifyLoginInvalidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=6,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInalidEmailInvalidPassword_FMCTest")
	public void VerifyLoginInalidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	//Add report functionality
	@Test(priority=7,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithValidDetails_FMCTest")
	public void VerifyAddReportWithValidDetails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		report=verifyReportFunctionality.getReportDetails(payload);
//		System.out.println(report.getReporter_details().getUser_id()+"\n"+report.getChild_details().getFullname()+"\n"+report.getIncident_details().getLocation());
		
		report.getReporter_details().setUser_id(userId);
		ResponseOptions<Response> response = verifyReportFunctionality.verifyAddReportFunctionality(methodName,serviceEndpoint,report, secureToken);
		JsonPath js=response.getBody().jsonPath();
		System.out.println(response.thenReturn().asString());
		content=js.getInt("content");
		softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=7,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest","VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithInValidUserId_FMCTest")
	public void VerifyAddReportWithInValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = verifyReportFunctionality.verifyAddReportFunctionalityWithStringBody(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=7,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest","VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithNoReporterDatails_FMCTest")
	public void VerifyAddReportWithNoReporterDatails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = verifyReportFunctionality.verifyAddReportFunctionalityWithStringBody(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=7,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest","VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithNoChildDetails_FMCTest")
	public void VerifyAddReportWithNoChildDetails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = verifyReportFunctionality.verifyAddReportFunctionalityWithStringBody(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=7,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest","VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithNoIncidentDetails_FMCTest")
	public void VerifyAddReportWithNoIncidentDetails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = verifyReportFunctionality.verifyAddReportFunctionalityWithStringBody(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=7,enabled=false,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest","VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithInValidToken_FMCTest")
	public void VerifyAddReportWithInValidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
	{	
		report=verifyReportFunctionality.getReportDetails(payload);
		String token=(String) getTestdata.getValue("invalidTokenOfSameLength");
		report.getReporter_details().setUser_id(userId);
		ResponseOptions<Response> response = verifyReportFunctionality.verifyAddReportFunctionality(methodName,serviceEndpoint,report, token);
//		System.out.println(response.getStatusCode());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	//get report functionality
	@Test(priority=8,enabled=true,dependsOnMethods={"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest","VerifyLoginValidEmailValidPassword_FMCTest","VerifyAddReportWithValidDetails_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyGetReportWithValidContent_FMCTest")
	public void VerifyGetReportWithValidContent_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		ResponseOptions<Response> response = verifyReportFunctionality.verifyGetReportFunctionality(methodName,serviceEndpoint,secureToken, verifyReportFunctionality.getReportPathParam(String.valueOf(content)));
		System.out.println(response.getBody().asString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=8,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyGetReportWithInValidToken_FMCTest")
	public void VerifyGetReportWithInValidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
	{	
		String token=(String) getTestdata.getValue("invalidTokenOfSameLength");
		ResponseOptions<Response> response = verifyReportFunctionality.verifyGetReportFunctionality(methodName,serviceEndpoint,token, verifyReportFunctionality.getReportPathParam(String.valueOf(content)));
//		System.out.println(response.getBody().asPrettyString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=8,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyGetReportWithInValidContent_FMCTest")
	public void VerifyGetReportWithInValidContent_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws NumberFormatException, IOException
	{	
		String invalidContent=(String) getTestdata.getValue("invalidContent");
		ResponseOptions<Response> response = verifyReportFunctionality.verifyGetReportFunctionality(methodName,serviceEndpoint,secureToken, verifyReportFunctionality.getReportPathParam(invalidContent));
		System.out.println(response.getBody().asString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	//Delete report functionality
	@Test(priority=9,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest","VerifyAddReportWithValidDetails_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithValidContentAndValidUserId_FMCTest")
	public void VerifyDeleteReportWithValidContentAndValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{	
		
		ResponseOptions<Response> response = verifyReportFunctionality.verifyDeleteReportFunctionality(methodName,serviceEndpoint,secureToken, String.valueOf(userId) , String.valueOf(content));
//		System.out.println(response.getBody().asPrettyString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=9,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest","VerifyAddReportWithValidDetails_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithInValidContentValidUserId_FMCTest")
	public void VerifyDeleteReportWithInValidContentValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
	{	
		String invalidContent=(String) getTestdata.getValue("invalidContent");
		ResponseOptions<Response> response = verifyReportFunctionality.verifyDeleteReportFunctionality(methodName,serviceEndpoint,secureToken, String.valueOf(userId) , invalidContent);
//		System.out.println(response.getBody().asPrettyString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=9,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest","VerifyAddReportWithValidDetails_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithValidContentInValidUserId_FMCTest")
	public void VerifyDeleteReportWithValidContentInValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
	{	
		String invalidUserId=(String) getTestdata.getValue("invalidUserId");
		ResponseOptions<Response> response = verifyReportFunctionality.verifyDeleteReportFunctionality(methodName,serviceEndpoint,secureToken, invalidUserId , String.valueOf(content));
//		System.out.println(response.getBody().asPrettyString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	@Test(priority=10,enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithValidEmailId_FMCTest")
    public void VerifyResetPasswordWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
	{	
      ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
      softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
      softAssert.assertAll();
	}
	
	@Test(priority=9,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest","VerifyAddReportWithValidDetails_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithInValidContentInvalidUserId_FMCTest")
	public void VerifyDeleteReportWithInValidContentInvalidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException
	{	
		String invalidUserId=(String) getTestdata.getValue("invalidUserId");
		String invalidContent=(String) getTestdata.getValue("invalidContent");
		ResponseOptions<Response> response = verifyReportFunctionality.verifyDeleteReportFunctionality(methodName,serviceEndpoint,secureToken, invalidUserId , invalidContent);
//		System.out.println(response.getBody().asPrettyString());
		softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
		softAssert.assertAll();
	}
	
	
//  Reset Password Functionality     
//    @Test(priority=10,enabled=true,dependsOnMethods={"VerifyLoginValidEmailValidPassword_FMCTest"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithValidEmailId_FMCTest")
//    public void VerifyResetPasswordWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
//    {    
//        ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
//        softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
//        softAssert.assertAll();
//    }
	
    
	
    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
