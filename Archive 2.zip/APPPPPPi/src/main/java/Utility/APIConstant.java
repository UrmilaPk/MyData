package Utility;

public class APIConstant {

    public static class ApiMethods {
        public static String POST = "POST";
        public static String GET = "GET";
        public static String DELETE = "DELETE";
    }
}
