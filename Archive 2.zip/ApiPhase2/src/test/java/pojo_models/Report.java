package pojo_models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@JsonIgnoreProperties(ignoreUnknown = true)
public class Report {
	
	
	
	public ReporterDetails getReporter_details() {
		return reporter_details;
	}
	public void setReporter_details(ReporterDetails reporter_details) {
		this.reporter_details = reporter_details;
	}
	public ChildDetails getChild_details() {
		return child_details;
	}
	public void setChild_details(ChildDetails child_details) {
		this.child_details = child_details;
	}
	public IncidentDetails getIncident_details() {
		return incident_details;
	}
	public void setIncident_details(IncidentDetails incident_details) {
		this.incident_details = incident_details;
	}
	private ReporterDetails reporter_details;
	private ChildDetails child_details;
	private IncidentDetails incident_details;

}
