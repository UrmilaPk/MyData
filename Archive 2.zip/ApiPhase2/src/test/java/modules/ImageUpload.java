package modules;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;

public class ImageUpload {
	
	public ResponseOptions<Response> verifyUploadImageFunctionality(String methodName, String serviceEndpoint, String path, String token){
	    	
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		File file=new File(path);
		return restAssuredEngine.executeWithFormBody(methodName, serviceEndpoint, file);
	}
    
	public ResponseOptions<Response> verifyUploadInvalidImageFunctionality(String methodName, String serviceEndpoint, String path, String token){
    	
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		File file=new File(path);
		return restAssuredEngine.executeWithFormBody(methodName, serviceEndpoint, file);
	}
	
   public ResponseOptions<Response> verifyDownloadImageFunctionality(String methodName, String serviceEndpoint, String filekey, String token){
    	
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		Map<String, String> hmap=new HashMap<String, String>();
		hmap.put("file_key", filekey);
		return restAssuredEngine.executeWithPathParams(methodName, serviceEndpoint, hmap);
		
	}
	
	
}
