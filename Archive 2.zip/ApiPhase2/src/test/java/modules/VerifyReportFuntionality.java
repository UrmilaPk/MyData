package modules;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.javafaker.Faker;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.Report;
import pojo_models.UserInfoWithLombok;

public class VerifyReportFuntionality {
	public ResponseOptions<Response> verifyAddReportFunctionality(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyGetReportFunctionality(String methodName, String serviceEndpoint,String token,Map<String, String> pathparams){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParams(methodName, serviceEndpoint,pathparams);
	}
	
	public ResponseOptions<Response> verifyDeleteReportFunctionality(String methodName, String serviceEndpoint, String token , String userId , String content){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		Map<String, String> pathParams=new  LinkedHashMap<String, String>();
		pathParams.put("content", content);
		pathParams.put("userId", userId);
		return restAssuredEngine.executeWithPathParams(methodName, serviceEndpoint , pathParams);
	}
	
	public int getInt()
	{
		Faker faker=new Faker();
		 return faker.number().randomDigit();
	}
	
	
	
	public Map<String, String> getReportPathParams(String content) {
    Map<String,String> map=new LinkedHashMap<String, String>();
    map.put("content", content);
   // map.put("userId", userId);
    return map;
	}
	
	public Report getReportInfoPayload(String payload) throws JsonMappingException, JsonProcessingException {
		try {
		ObjectMapper mapper=new ObjectMapper();
		Report reportInfo=mapper.readValue(payload,Report.class );
		return reportInfo;
	    }
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
