package modules;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.io.FileNotFoundException;

public class GetTestData {
	public Object getTestValue(String key) throws IOException {
	Properties prop=new Properties();
	FileReader reader=new FileReader("/Users/urmila.dulange/eclipse-workspace/SelfPractice/src/test/resources/TestData.properties");
	prop.load(reader);
	return prop.get(key);
	
	}
}
