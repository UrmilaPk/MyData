package modules;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import Utility.RestAssuredEnginep;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import pojo_models.UserInfoWithLombok;
import Utility.ExcelUtility;
//import pojo_models.UserInfoWithLombok;
import Utility.RestAssuredEngine;

public class UserSignUp {
	
	public ResponseOptions<Response> verifyEmailId(String methodName, String serviceEndpoint, String payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, payload);
	}
	
	public ResponseOptions<Response> verifyEmailId(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	
	public ResponseOptions<Response> verifyOtp(String methodName, String serviceEndpoint, Object payload, String token){
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(methodName, serviceEndpoint, payload);
	}
	
	
	public UserInfoWithLombok getUserInfoPayload(String payload) throws JsonMappingException, JsonProcessingException {
		try {
		ObjectMapper mapper=new ObjectMapper();
		UserInfoWithLombok userInfo=mapper.readValue(payload,UserInfoWithLombok.class );
		return userInfo;
	    }
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}
	
	public ResponseOptions<Response> getOtp( String token, String module,Object payload) throws EncryptedDocumentException, InvalidFormatException, IOException{
		ArrayList<String> list=new ArrayList<String>(ExcelUtility.getAPIparams(module));
		RestAssuredEnginep restAssuredEngine = new RestAssuredEnginep(token);
		return restAssuredEngine.executeWithPathParamsAndBody(list.get(2), list.get(0)+list.get(1),payload);
	}
	public ResponseOptions<Response> addOTP(String token, String module ,Object payload) throws EncryptedDocumentException, InvalidFormatException, IOException
	{
		ArrayList<String> list=new ArrayList<String>(ExcelUtility.getAPIparams(module));
		RestAssuredEnginep restAssuredEnginep = new RestAssuredEnginep(token);
		return restAssuredEnginep.executeWithPathParamsAndBody(list.get(2), list.get(0)+list.get(1),payload);
		
	}

	
	
	
}

