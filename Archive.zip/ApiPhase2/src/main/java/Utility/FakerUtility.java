package Utility;

import com.github.javafaker.Faker;

public class FakerUtility {
	
	   public String getEmailId() {
		   Faker faker=new Faker();
		   return faker.internet().emailAddress();
	   }
	   
	   public String getPassword() {
		   Faker faker=new Faker();
		   return faker.internet().password(); 	
		   
	   }
	   
	   public String getPhoneNo() {
		   Faker faker=new Faker();
		   return faker.phoneNumber().cellPhone(); 
		   }
	  
	   public String getFullName() {
		   Faker faker=new Faker();
		   return faker.name().fullName(); 
		
		   
	   }
      
	   
}
