package tests.FrameworkTests;

import org.testng.annotations.Test;
import org.testng.*;
import java.io.IOException;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import Test.BaseTest;
import Utility.ExcelUtility;
import Utility.FakerUtility;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import modules.GetTestData;
import modules.UserSignUp;
import pojo_models.EmailSignUpLombok;

import pojo_models.LoginWithLombok;
import pojo_models.UserInfoWithLombok;

public class UtilityTests extends BaseTest{
	UserSignUp userSignUp=new UserSignUp();
	SoftAssert softAssert=new SoftAssert();
	GetTestData getTestData=new GetTestData();
	UserInfoWithLombok userInfo=new UserInfoWithLombok();
	String invalidToken="";
	String Otp="";
	
	EmailSignUpLombok emailsignUp=new EmailSignUpLombok();
	FakerUtility fakerUtility=new FakerUtility();
	
	//Verify EmailId Functinality
		@Test(enabled=true,priority=0,groups={"positive", "signup"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
		public void VerifyEmailFieldValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) {
			
			ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
//			JsonPath js=response.getBody().jsonPath();
//			Otp=js.getString("content.otp");
//			System.out.println(Otp);
			
		}
		
		@Test(enabled=false,priority=0,groups={"negative", "signup"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidEmailId_FMCTest")
		public void VerifyEmailFieldInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) {
			
			ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
		}
		@Test(enabled=false,priority=0,groups={"negative", "signup"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidToken_FMCTest")
		public void VerifyEmailFieldInvalidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
			invalidToken=(String) getTestData.getTestValue("invalidTokenOfSameLength");
			ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload, invalidToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
		}
		
		//Verify Otp 
		
		@Test(enabled=true,priority=1,groups={"positive", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpValidOtp_FMCTest")
		public void VerifyOtpValidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
			userInfo.setEmail_id(emailsignUp.getEmail_id());
			userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
			userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		@Test(enabled=true,priority=0,groups={"negative", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidOtp_FMCTest")
		public void VerifyOtpInvalidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
			userInfo.setEmail_id(emailsignUp.getEmail_id());
			//userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
			userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		
		@Test(enabled=true,priority=0,groups={"negative", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidEmailId_FMCTest")
		public void VerifyOtpInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
		//	userInfo.setEmail_id(emailsignUp.getEmail_id());
			userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
			userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		@Test(enabled=true,priority=0,groups={"negative", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpWithPhoneNoFieldBlank_FMCTest")
		public void VerifyOtpWithPhoneNoFieldBlank_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
			userInfo.setEmail_id(emailsignUp.getEmail_id());
			userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
			userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		@Test(enabled=true,priority=0,groups={"negative", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPhoneNo_FMCTest")
		public void VerifyOtpInvalidPhoneNo_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
			userInfo.setEmail_id(emailsignUp.getEmail_id());
			userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
			userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		
		@Test(enabled=true,priority=0,groups={"negative", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPassword_FMCTest")
		public void VerifyOtpInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
			userInfo.setEmail_id(emailsignUp.getEmail_id());
			userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
		  //  userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		@Test(enabled=true,priority=0,groups={"negative", "OTP"},dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidName_FMCTest")
		public void VerifyOtpInvalidName_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException, EncryptedDocumentException, InvalidFormatException {
			
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
			Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);  
			userInfo=userSignUp.getUserInfoPayload(payload);
			userInfo.setEmail_id(emailsignUp.getEmail_id());
			userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
			userInfo.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint, userInfo, secureToken);
			softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
			softAssert.assertAll();
			
		}
		
		//login Functionality
		@Test(priority=2,groups={"positive", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailValidPassword_FMCTest")
		public void VerifyLoginValidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws EncryptedDocumentException, InvalidFormatException, IOException
		{	
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
	    	Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);   	
	    	userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
	    	userInfo.setEmail_id(emailsignUp.getEmail_id());
	    	userInfo.setPassword(fakerUtility.getPassword());	
	    	userInfo.setFull_name(fakerUtility.getFullName());
	    	userInfo.setPhone_number(fakerUtility.getPhoneNo());    	
	    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
	    	LoginWithLombok login=new LoginWithLombok();
	    	login.setEmail_id(emailsignUp.getEmail_id());
	    	login.setPassword(userInfo.getPassword());
			ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//			JsonPath js=response.getBody().jsonPath();
			SoftAssert softAssert=new SoftAssert();
			softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
			softAssert.assertAll();
		}
		
		@Test(priority=4,groups={"negative", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailInvalidPassword_FMCTest")
		public void VerifyLoginValidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws EncryptedDocumentException, InvalidFormatException, IOException
		{	
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
	    	Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);   	
	    	userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
	    	userInfo.setEmail_id(emailsignUp.getEmail_id());
	    	userInfo.setPassword(fakerUtility.getPassword());	
	    	userInfo.setFull_name(fakerUtility.getFullName());
	    	userInfo.setPhone_number(fakerUtility.getPhoneNo());    	
	    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
	    	LoginWithLombok login=new LoginWithLombok();
	    	login.setEmail_id(emailsignUp.getEmail_id());
	    	login.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//			JsonPath js=response.getBody().jsonPath();
			SoftAssert softAssert=new SoftAssert();
			softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
			softAssert.assertAll();
		}
		
		@Test(priority=4,groups={"negative", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInvalidEmailValidPassword_FMCTest")
		public void VerifyLoginInvalidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws EncryptedDocumentException, InvalidFormatException, IOException
		{	
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
	    	Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);   	
	    	userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
	    	userInfo.setEmail_id(emailsignUp.getEmail_id());
	    	userInfo.setPassword(fakerUtility.getPassword());	
	    	userInfo.setFull_name(fakerUtility.getFullName());
	    	userInfo.setPhone_number(fakerUtility.getPhoneNo());    	

	    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
	    	LoginWithLombok login=new LoginWithLombok();
	    	login.setEmail_id(fakerUtility.getEmailId());
	    	login.setPassword(userInfo.getPassword());
			ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//			JsonPath js=response.getBody().jsonPath();
			SoftAssert softAssert=new SoftAssert();
			softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
			softAssert.assertAll();
		}
		
		
		@Test(priority=4,groups={"negative", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInalidEmailInvalidPassword_FMCTest")
		public void VerifyLoginInalidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws EncryptedDocumentException, InvalidFormatException, IOException
		{	
			emailsignUp.setEmail_id(fakerUtility.getEmailId());
	    	Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);   	
	    	userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
	    	userInfo.setEmail_id(emailsignUp.getEmail_id());
	    	userInfo.setPassword(fakerUtility.getPassword());	
	    	userInfo.setFull_name(fakerUtility.getFullName());
	    	userInfo.setPhone_number(fakerUtility.getPhoneNo());    	
	
	    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
	    	LoginWithLombok login=new LoginWithLombok();
	    	login.setEmail_id(fakerUtility.getEmailId());
	    	login.setPassword(fakerUtility.getPassword());
			ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
//			JsonPath js=response.getBody().jsonPath();
			SoftAssert softAssert=new SoftAssert();
			softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
			softAssert.assertAll();
		}
		
//		@Test(priority=4,groups={"positive", "login"},enabled=true,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginAfterResetPasswordWithOldPassword_FMCTest")
//		public void VerifyLoginAfterResetPasswordWithOldPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws EncryptedDocumentException, InvalidFormatException, IOException
//		{	
//			emailsignUp.setEmail_id(fakerUtility.getEmailId());
//	    	Response otp=(Response)userSignUp.getOtp(secureToken, "EmailSignUp", emailsignUp);   	
//	    	userInfo.setOtp(otp.getBody().jsonPath().getString("content.otp"));
//	    	userInfo.setEmail_id(emailsignUp.getEmail_id());
//	    	userInfo.setPassword(fakerUtility.getPassword());	
//	    	userInfo.setFull_name(fakerUtility.getFullName());
//	    	userInfo.setPhone_number(fakerUtility.getPhoneNo());    	
////	    	UserInfoWithLombok.builder().email_id(emailSignUpWithLombok.getEmail_id()).full_name(userSignUp.getFullname()).otp(otp.jsonPath().get("content."OTP"})).password(payload).phone_number(payload).build(); 	
//	    	userSignUp.addOTP(secureToken, "VeryfyOTP", userInfo);    	
//	    	LoginWithLombok login=new LoginWithLombok();
//	    	login.setEmail_id(fakerUtility.getEmailId());
//	    	login.setPassword(userInfo.getPassword());
//			ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,login, secureToken);
////			JsonPath js=response.getBody().jsonPath();
//			SoftAssert softAssert=new SoftAssert();
//			softAssert.assertEquals(response.getStatusCode(), statusCode,"Status code failed");
//			softAssert.assertAll();
//		}
}
