package tests.FrameworkTests;

import org.testng.annotations.Test;
import org.testng.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import Test.BaseTest;

import Utility.ExcelUtility;
import Utility.FakerUtility;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import modules.GetTestData;
import modules.ImageUpload;
import modules.LoginHelper;
import modules.UserSignUp;
import modules.VerifyReportFuntionality;
import pojo_models.EmailSignUpLombok;

import pojo_models.IncidentDetails;

import pojo_models.LoginWithLombok;
import pojo_models.Report;
import pojo_models.UserInfoWithLombok;

public class PracticeC1 extends BaseTest{
	UserSignUp userSignUp=new UserSignUp();
	SoftAssert softAssert=new SoftAssert();
	GetTestData getTestData=new GetTestData();
	UserInfoWithLombok userInfo=new UserInfoWithLombok();
	String Otp="";
	VerifyReportFuntionality verifyReportFuntionality = new VerifyReportFuntionality();
	Report reportInfo=new Report();
	int userId;
	IncidentDetails incidentDetails=new IncidentDetails();
	String invalidToken="";
	int content;
	String image="";
	ImageUpload imagefile=new ImageUpload();
	String file_key="";
	String invalidFileKey="";
	LoginHelper loginHelper=new LoginHelper();
	FakerUtility fakerUtility = null;
	EmailSignUpLombok emailsignUp=new EmailSignUpLombok();
	
	
//	//Verify EmailId Functinality
//	@Test(enabled=true,priority=0,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
//	public void VerifyEmailFieldValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) {
//		
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload, secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//		JsonPath js=response.getBody().jsonPath();
//		Otp=js.getString("content.otp");
//		System.out.println(Otp);
//		
//	}
//	
//	@Test(enabled=false,priority=0,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidEmailId_FMCTest")
//	public void VerifyEmailFieldInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) {
//		
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload, secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	@Test(enabled=false,priority=0,dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldInvalidToken_FMCTest")
//	public void VerifyEmailFieldInvalidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
//		invalidToken=(String) getTestData.getTestValue("invalidTokenOfSameLength");
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload, invalidToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	//verify otp
//	@Test(enabled=true,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpValidOtp_FMCTest")
//	public void VerifyOtpValidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//		userInfo=userSignUp.getUserInfoPayload(payload);
//		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint,userInfo , secureToken);
//		
//		System.out.println(response.getBody().asPrettyString());
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidOtp_FMCTest")
//	public void VerifyOtpInvalidOtp_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//	    userInfo=userSignUp.getUserInfoPayload(payload);
////		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint,userInfo , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidEmailId_FMCTest")
//	public void VerifyOtpInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//	    userInfo=userSignUp.getUserInfoPayload(payload);
//		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint,userInfo , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPhoneNo_FMCTest")
//	public void VerifyOtpInvalidPhoneNo_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//	    userInfo=userSignUp.getUserInfoPayload(payload);
//		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint,userInfo , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidPassword_FMCTest")
//	public void VerifyOtpInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//	    userInfo=userSignUp.getUserInfoPayload(payload);
//		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint,userInfo , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	
//	@Test(enabled=true,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyOtpInvalidName_FMCTest")
//	public void VerifyOtpInvalidName_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//	    userInfo=userSignUp.getUserInfoPayload(payload);
//		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyOtp( methodName,  serviceEndpoint,userInfo , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	
//	//verify Login functionality
//	@Test(enabled=true,priority=2,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailValidPassword_FMCTest")
//	public void VerifyLoginValidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
////	    userInfo=userSignUp.getUserInfoPayload(payload);
////		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint,payload , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//		JsonPath js=response.getBody().jsonPath();
//	    userId=js.get("content.userId");
//	    System.out.println(userId);
//	}
//	
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginValidEmailInvalidPassword_FMCTest")
//	public void VerifyLoginValidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
////	    userInfo=userSignUp.getUserInfoPayload(payload);
////		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint,payload , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInvalidEmailValidPassword_FMCTest")
//	public void VerifyLoginInvalidEmailValidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
////	    userInfo=userSignUp.getUserInfoPayload(payload);
////		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint,payload , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
//	
//	@Test(enabled=false,priority=1,dependsOnMethods = {"VerifyEmailFieldValidEmailId_FMCTest","VerifyOtpValidOtp_FMCTest"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyLoginInalidEmailInvalidPassword_FMCTest")
//	public void VerifyLoginInalidEmailInvalidPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
////	    userInfo=userSignUp.getUserInfoPayload(payload);
////		userInfo.setOtp(Otp);
//		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint,payload , secureToken);
//		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
//		softAssert.assertAll();
//	}
	
	
	
	@BeforeMethod (enabled=true)
	public void VerifyLoginValidEmailValidPassword_FMCTest() throws IOException, EncryptedDocumentException, InvalidFormatException
	{	
		LoginWithLombok login=new LoginWithLombok();
		login.setEmail_id((String) getTestData.getTestValue("email_id"));
		login.setPassword((String) getTestData.getTestValue("password"));
//		login.setEmail_id(emailsignUp.getEmail_id());
//    	login.setPassword(userInfo.getPassword());
		ResponseOptions<Response> response = loginHelper.loginUser(secureToken,"Login",login);
		JsonPath js=response.getBody().jsonPath();
		userId=js.getInt("content.userId");

	}
	
	//Add report functionality
	@Test(enabled=true,priority=3,groups={"positive", "addreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithValidDetails_FMCTest")
	public void VerifyAddReportWithValidDetails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
        reportInfo.getReporter_details().setRequest_id(String.valueOf(verifyReportFuntionality.getInt()));

		ResponseOptions<Response> response=verifyReportFuntionality.verifyAddReportFunctionality( methodName,  serviceEndpoint,reportInfo , secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
		JsonPath js=response.getBody().jsonPath();
		content=js.get("content");
		
	}
	
	@Test(enabled=true,priority=4,groups={"negative", "addreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithInValidUserId_FMCTest")
	public void VerifyAddReportWithInValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
        reportInfo.getReporter_details().setRequest_id(String.valueOf(verifyReportFuntionality.getInt()));

       // reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		ResponseOptions<Response> response=verifyReportFuntionality.verifyAddReportFunctionality( methodName,  serviceEndpoint,reportInfo , secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=4,groups={"negative", "addreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithNoReporterDatails_FMCTest")
	public void VerifyAddReportWithNoReporterDatails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
//        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		ResponseOptions<Response> response=verifyReportFuntionality.verifyAddReportFunctionality( methodName,  serviceEndpoint,reportInfo , secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=4,groups={"negative", "addreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithNoChildDetails_FMCTest")
	public void VerifyAddReportWithNoChildDetails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		ResponseOptions<Response> response=verifyReportFuntionality.verifyAddReportFunctionality( methodName,  serviceEndpoint,reportInfo , secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=4,groups={"negative", "addreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithNoIncidentDetails_FMCTest")
	public void VerifyAddReportWithNoIncidentDetails_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
        reportInfo.getReporter_details().setUser_id(userId);
        reportInfo.getReporter_details().setRequest_id(String.valueOf(verifyReportFuntionality.getInt()));

       // System.out.println(userId);
		ResponseOptions<Response> response=verifyReportFuntionality.verifyAddReportFunctionality( methodName,  serviceEndpoint,reportInfo , secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=4,groups={"negative", "addreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyAddReportWithInValidToken_FMCTest")
	public void VerifyAddReportWithInValidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
        reportInfo.getReporter_details().setUser_id(userId);
        invalidToken=(String) getTestData.getTestValue("invalidTokenOfSameLength");
        reportInfo.getReporter_details().setRequest_id(String.valueOf(verifyReportFuntionality.getInt()));

        // System.out.println(userId);
		ResponseOptions<Response> response=verifyReportFuntionality.verifyAddReportFunctionality( methodName,  serviceEndpoint,reportInfo , invalidToken);
		response.getBody().jsonPath().prettyPrint();
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	//Get report functionality
	@Test(enabled=true,priority=5,groups={"positive", "getreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyGetReportWithValidContent_FMCTest")
	public void VerifyGetReportWithValidContent_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
//        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		ResponseOptions<Response> response=verifyReportFuntionality.verifyGetReportFunctionality( methodName,  serviceEndpoint,secureToken,verifyReportFuntionality.getReportPathParams(String.valueOf(content)));
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=6,groups={"negative", "getreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyGetReportWithInValidToken_FMCTest")
	public void VerifyGetReportWithInValidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
        invalidToken=(String) getTestData.getTestValue("invalidTokenOfSameLength");
		ResponseOptions<Response> response=verifyReportFuntionality.verifyGetReportFunctionality( methodName,  serviceEndpoint,secureToken,verifyReportFuntionality.getReportPathParams(String.valueOf(content)));
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=6,groups={"negative", "getreport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyGetReportWithInValidContent_FMCTest")
	public void VerifyGetReportWithInValidContent_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
		String invalidContent=(String) getTestData.getTestValue("invalidContent");
		ResponseOptions<Response> response=verifyReportFuntionality.verifyGetReportFunctionality( methodName,  serviceEndpoint,secureToken,verifyReportFuntionality.getReportPathParams(invalidContent));
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	//Verify Delete Report Functionality
	@Test(enabled=true,priority=7,groups={"positive", "deletereport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithValidContentAndValidUserId_FMCTest")
	public void VerifyDeleteReportWithValidContentAndValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
        
		ResponseOptions<Response> response=verifyReportFuntionality.verifyDeleteReportFunctionality( methodName,  serviceEndpoint,secureToken,String.valueOf(userId),String.valueOf(content));
		System.out.println(response.getBody().asPrettyString());
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=8,groups={"negative", "deletereport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithInValidContentValidUserId_FMCTest")
	public void VerifyDeleteReportWithInValidContentValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
		String invalidContent=(String) getTestData.getTestValue("invalidContent");
		ResponseOptions<Response> response=verifyReportFuntionality.verifyDeleteReportFunctionality( methodName,  serviceEndpoint,secureToken,String.valueOf(userId),invalidContent);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=8,groups={"negative", "deletereport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithValidContentInValidUserId_FMCTest")
	public void VerifyDeleteReportWithValidContentInValidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
		String validContent=(String) getTestData.getTestValue("validContent");
		String invaliduserId=(String) getTestData.getTestValue("invalidUserId");
		ResponseOptions<Response> response=verifyReportFuntionality.verifyDeleteReportFunctionality( methodName,  serviceEndpoint,secureToken,invaliduserId,String.valueOf(content));
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=8,groups={"negative", "deletereport"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteReportWithInValidContentInvalidUserId_FMCTest")
	public void VerifyDeleteReportWithInValidContentInvalidUserId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
		String invalidContent=(String) getTestData.getTestValue("invalidContent");
		String invaliduserId=(String) getTestData.getTestValue("invalidUserId");
		ResponseOptions<Response> response=verifyReportFuntionality.verifyDeleteReportFunctionality( methodName,  serviceEndpoint,secureToken,invaliduserId,invalidContent);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	
	//Reset Password Functionality
	@Test(enabled=true,priority=9,groups={"positive", "resetpassword"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithValidEmailId_FMCTest")
	public void VerifyResetPasswordWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
//        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		LoginWithLombok login=loginHelper.getCredentialsAsObject(payload);
		
		login.setPassword(fakerUtility.getPassword());
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=10,groups={"negative", "resetpassword"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithInValidEmailId_FMCTest")
	public void VerifyResetPasswordWithInValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
//        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
         LoginWithLombok login=loginHelper.getCredentialsAsObject(payload);
		
		login.setPassword(fakerUtility.getEmailId());
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=10,groups={"negative", "resetpassword"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithoutPassword_FMCTest")
	public void VerifyResetPasswordWithoutPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
//        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=10,groups={"negative", "resetpassword"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithExistingPassword_FMCTest")
	public void VerifyResetPasswordWithExistingPassword_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws JsonMappingException, JsonProcessingException {
//        reportInfo=verifyReportFuntionality.getReportInfoPayload(payload);
//        reportInfo.getReporter_details().setUser_id(userId);
       // System.out.println(userId);
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=10,groups={"negative", "resetpassword"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyResetPasswordWithInValidAuthToken_FMCTest")
	public void VerifyResetPasswordWithInValidAuthToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
        invalidToken=(String) getTestData.getTestValue("invalidTokenOfSameLength");
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,invalidToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	
	//Verify Image Upload Functionality
	@Test(enabled=true,priority=11,groups={"positive", "imageupload"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyImageUploadWithValidFormat_FMCTest")
	public void VerifyImageUploadWithValidFormat_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
        image=(String) getTestData.getTestValue("path");
		ResponseOptions<Response> response=imagefile.verifyUploadImageFunctionality( methodName,  serviceEndpoint, image,secureToken);
		file_key=response.getBody().jsonPath().getString("image_file_key");
		System.out.println(file_key);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=12,groups={"negative", "imageupload"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyImageUploadInvalidFormat_FMCTest")
	public void VerifyImageUploadInvalidFormat_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
     //   image=(String) getTestData.getTestValue("path");
		ResponseOptions<Response> response=imagefile.verifyUploadImageFunctionality( methodName,  serviceEndpoint, image,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=12,groups={"negative", "imageupload"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyImageUploadWithoutImage_FMCTest")
	public void VerifyImageUploadWithoutImage_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
     //   image=(String) getTestData.getTestValue("path");
		image=(String) getTestData.getTestValue("invalidFilePath");
		ResponseOptions<Response> response=imagefile.verifyUploadImageFunctionality( methodName,  serviceEndpoint, image,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
    //verify Image Download functionality
	@Test(enabled=true,priority=13,groups={"positive", "imagedownload"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyImageDownloadWithValidFileKey_FMCTest")
	public void VerifyImageDownloadWithValidFileKey_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
     
		ResponseOptions<Response> response=imagefile.verifyDownloadImageFunctionality( methodName,  serviceEndpoint, file_key,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=14,groups={"negative", "imagedownload"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyImageDownloadWithInvalidFileKey_FMCTest")
	public void VerifyImageDownloadWithInvalidFileKey_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
        invalidFileKey=(String) getTestData.getTestValue("invalidFileKey");
		ResponseOptions<Response> response=imagefile.verifyDownloadImageFunctionality( methodName,  serviceEndpoint, invalidFileKey,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	//Verify Delete User Functionality
	@Test(enabled=true,priority=15,groups={"positive", "deleteuser"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteUserFunctionaityWithValidEmailId_FMCTest")
	public void VerifyDeleteUserFunctionaityWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
		 EmailSignUpLombok emailSignUpWithLombok=new EmailSignUpLombok();
		 emailSignUpWithLombok.setEmail_id((String) getTestData.getTestValue("SignedEmail"));
		 //emailSignUpWithLombok.setEmail_id(fakerUtility.getEmailId());
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	
	@Test(enabled=true,priority=16,groups={"negative", "deleteuser"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteUserFunctionaityWithInvalidEmailId_FMCTest")
	public void VerifyDeleteUserFunctionaityWithInvalidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
		EmailSignUpLombok emailSignUpWithLombok=new EmailSignUpLombok();
		emailSignUpWithLombok.setEmail_id(fakerUtility.getEmailId());
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,secureToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
	
	@Test(enabled=true,priority=16,groups={"negative", "deleteuser"},dataProvider=  "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyDeleteUserFunctionaityWithInvalidToken_FMCTest")
	public void VerifyDeleteUserFunctionaityWithInvalidToken_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode) throws IOException {
        invalidToken=(String) getTestData.getTestValue("invalidTokenOfSameLength");
        EmailSignUpLombok emailSignUpWithLombok=new EmailSignUpLombok();
		 emailSignUpWithLombok.setEmail_id((String) getTestData.getTestValue("SignedEmail"));
		ResponseOptions<Response> response=userSignUp.verifyEmailId( methodName,  serviceEndpoint, payload,invalidToken);
		softAssert.assertEquals(response.getStatusCode(), statusCode, "Status code failed");
		softAssert.assertAll();
	}
}
















