package pojo_models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class EmailSignUpLombok {
	
	private String email_id;

}
