package programspractice;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class OccurenceOfWords {
	
	public static void main(String[] args) {
		
		String line="Rain rain come again";
		String[] s=line.split(" ");
		int count=1;
		HashMap<String, Integer> mp=new HashMap<String, Integer>();
		for(int i=0;i<s.length;i++) {
			if(!mp.containsKey(s[i])) {
				mp.put(s[i], count);
			}
			else {
				mp.put(s[i], mp.get(s[i])+1);
			}
		}
		
		for(Map.Entry entry:mp.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
		
		
	}

}
