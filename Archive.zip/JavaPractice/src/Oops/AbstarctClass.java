package Oops;

abstract class AbstarctClass {
  
	public  abstract  void m1();
	public  abstract void m2();
  
}

abstract class Subabstract extends AbstarctClass{

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}

class SubofSubabstract extends AbstarctClass{

	@Override
	public void m1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}

class SubSubofSubAbstract extends Subabstract{

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}
	
	
}
	
}
	

	
}