package Oops;

public class FinalMethod {
	
	static final void m1() {
		System.out.println("hello");
	}
	
	static final void m1(int i) {      //we can overload final method
		
		System.out.println("hello"+" "+i); 
		
	}
	  final int a=1;
      static int b=20;
	
	public static void main(String[] args) {
		m1();
		m1(10);
		
		FinalMethod fc=new FinalMethod();
        System.out.println(fc.a);
        System.out.println(b);
		fc.b=30;
		System.out.println(b);
		
	}
	

}

