package Oops;

public class Subpolymorpism extends Polymorphism {
    
	public Subpolymorpism() {
		super(6,9);
	}
	
	public int sum(int a,int b) {
		int sm=a+b+100;
		return sm;
	}
	
	
	public static void main(String[] args) {
		Subpolymorpism sb=new Subpolymorpism();
		System.out.println(sb.sum(4, 5));
		Polymorphism pl=new Polymorphism(5,6);
		System.out.println(pl.sum(6, 1));
		
	}
	
	
	
}
