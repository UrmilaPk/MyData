package Oops;

public abstract class Abstract {
	
	//abstract method
	//1.abstract method only have declaration not having body or implementation
	//2.only child class can provide implementation/body to abstract method
	
	//Abstract class 
	//3.if class is having atleast one abstract method then compulsory that class must be abstract class
	//4.abstract class is nothing but unimplemented or partial implemented class 
	//5.we can not create object of abstract class
	//6. if class doesn't contains abstract method at all even though we can declare class as abstract class 
	//i.e if implementation is not that much proper so we want to restrict object creation of that class so we can make that class as abstract
	
	// Ex: 
	//   public abstract class abs{
	
	//            public void m1(){}         here we have created method and having body but still not implemented properly 
	//            public void m2(){}         even if we create object here i.e not meaningful so make that class as abstract 
	
	
	//   }
	
	
	//Example
	//    1. public abstract void m1(){}     ----- false
	//    2.public void m1();                -----false
	//    3. public abstract void m1();      -----true
	//    4. public void m1(){}              ------true
	
	public abstract int getNoOfWheels();//here we need to return no of Wheels which depends on type of Vehicle , here 
	                                    // we dont know exact type of vehicle 
	

}


