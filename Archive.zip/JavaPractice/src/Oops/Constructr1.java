package Oops;

public class Constructr1 {
	String name;
	int rollno;
	
	public Constructr1(String name,int rollno) {
		this.name=name;
		this.rollno=rollno;
	}
	
	
	public static void main(String[] args) {
		Constructr1 c1=new Constructr1("APK",1);
//		c1.name="APK";
//		c1.rollno=1;
		Constructr1 c2=new Constructr1("APKA",2);
		Constructr1 c3=new Constructr1("APKB",3);
		System.out.println(c1.name+" "+c2.rollno+" "+c3.name);
		System.out.println(c1+" "+c2+" "+c3);
	}

}

//Uses of : super(),this() --- constructor call 
// 1.we can only use inside constructor
// 2.and inside constructor only in first line we can use them means  
// 3.we can use only one simultaneously we can not use both
