package Oops;

public class OverrideFinalMethod extends FinalMethod {
	
	static final void m1() {      //We can not override final methods
		System.out.println("hello");
	}

}
