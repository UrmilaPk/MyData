package Oops;

public class ConstructorCalls {
// case 1:dont write any constructor in both parent and child class then default constructor call gets called. this is valid 
	
//case 2:writing no arg constctr in parent and not writing any constctr in child,then as in child class default constctr gets called
//	 which include super() which calls parent class no arg constrctr.  this case is also valid     
		
	//public ConstructorCalls() { }
	
// case 3:writing  arg constctr in parent and not writing any constctr in child,then as in child class default constctr gets called
//	 which include super() which calls parent class no arg constrctr,but no arg constrctr is not present in parent so gets compile time error
//   this is not valid case

   public ConstructorCalls(int i) {
	
   }
   
   public ConstructorCalls() {
	   
   }

// Solution 1: in child class also we need to write arg constructor 
//solution 2: or whenever we are writing arg constructor in parent write one more no arg constructor in parent so that 
// child default constructor gets matched with parent no arg constructor 
	
	
	
}
 