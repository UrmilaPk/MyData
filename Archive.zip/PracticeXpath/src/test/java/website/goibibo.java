package website;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.github.bonigarcia.wdm.WebDriverManager;

public class goibibo {
	
//	//div[@class='sc-ksdxgE dvdvQX fswFld ']/span[text()='From']/following-sibling::p[text()='Enter city or airport']
//  //span[text()='From']/following-sibling::p[text()='Enter city or airport']
	
//  //p[text()='Enter city or airport']/preceding-sibling::span[text()='From']
	
//  //a[text()='Hotels']
	
// //span[text()='Round-trip']
	
	public static void main(String[] args) {
		
	WebDriver driver=	WebDriverManager.chromedriver().create();
	driver.get("https://www.goibibo.com/");
	driver.manage().window().maximize();
	WebElement e=driver.findElement(By.xpath("//p[text()='Offers For You']"));
	JavascriptExecutor js=  (JavascriptExecutor)driver;
	js.executeScript("arguments[0].scrollIntoView();",e);
	
    List<WebElement> l=driver.findElements(By.xpath("//ul[@class='sc-zdy0j7-3 gYApmL']/li"));
    System.out.println(l.size());
  
  for(int i=1;i<=l.size();i++) {
	  String s=driver.findElement(By.xpath("//ul[@class='sc-zdy0j7-3 gYApmL']/li["+i+"]")).getText();
	  System.out.println(s);
  }
	
		
	}
	
}
