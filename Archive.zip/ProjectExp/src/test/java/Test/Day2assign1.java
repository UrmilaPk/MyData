package Test;

import org.hamcrest.Matchers;
import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import java.util.List;

public class Day2assign1 
{
	@Test 
	public void requestBookingIds_checkStatusCode_expectHttp200()
	{
		given().
		when().
			get("https://restful-booker.herokuapp.com/booking").
		then().
			assertThat().
			statusCode(200);
	}
	
	@Test
	public void requestBookingIds_logRequestAndResponseDetails()
	{
		given().
			log().all().
		when().
			get("https://restful-booker.herokuapp.com/booking").
		then().
			log().body();
	}
	
	@Test
	public void requestBookingIds_checkBookingIdsInResponseBody()
	{
		Response response=given().
		when().
			get("https://restful-booker.herokuapp.com/booking");
		JsonPath jsonpath=response.jsonPath();
		List<Integer> allBookingId=jsonpath.getList("bookingid");
		for(int bookingId : allBookingId)
		{
			System.out.println(bookingId);
		}		
		response.then().
			assertThat().
			body("bookingid", Matchers.hasItem(4961));
	}
	


	

}
