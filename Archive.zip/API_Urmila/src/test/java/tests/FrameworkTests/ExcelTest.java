package tests.FrameworkTests;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import io.restassured.specification.RequestSpecification;
import modules.UserSignUp;
import tests.BaseTest;
import utilities.ExcelUtility;

public class ExcelTest extends BaseTest {
	
	UserSignUp userSignUp = new UserSignUp();
	SoftAssert softAssert = new SoftAssert();
	RequestSpecification requestSpecification;
	String otp="";
	
	
	@Test(dataProvider = "getApiEndPointData2", dataProviderClass = ExcelUtility.class,testName="VerifyEmailFieldWithValidEmailId_FMCTest")
	public void VerifyEmailFieldWithValidEmailId_FMCTest(String methodName, String serviceEndpoint, String payload, int statusCode)
	{
		ResponseOptions<Response> response = userSignUp.verifyEmailId(methodName,serviceEndpoint,payload, secureToken);
		softAssert.assertEquals(response.getStatusCode(), 200,"Status code failed");
		JsonPath js=response.getBody().jsonPath();
		otp=js.get("content.otp");
		System.out.println(otp);
	}

}
