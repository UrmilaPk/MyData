package modules;

import java.util.Map;

import io.restassured.response.Response;
import io.restassured.response.ResponseOptions;
import utilities.RestAssuredEngine;

public class UserSignUp {
	
	public ResponseOptions<Response> verifyEmailId(String methodName, String serviceEndpoint, String payload, String token){
		RestAssuredEngine restAssuredEngine = new RestAssuredEngine(token);
		return restAssuredEngine.executeMethod(methodName, serviceEndpoint, payload);
	}

}
