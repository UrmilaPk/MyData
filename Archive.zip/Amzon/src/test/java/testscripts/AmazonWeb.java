package testscripts;

import org.openqa.selenium.WebDriver;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AmazonWeb {
	
	public static void main(String[] args) {
	
	WebDriver driver=WebDriverManager.chromedriver().create();
	driver.get("https://www.amazon.in/");
	driver.manage().window().maximize();
	System.out.println(driver.getTitle());
	String actualTitle=driver.getTitle();
	String expTitle="Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
	
	if(actualTitle.equalsIgnoreCase(expTitle))
		System.out.println("correct title");
	else
		System.out.println("failed");
	
	driver.close();
	
	
	}

}
